package salonhabanafx;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Sandra
 */
public class SalonHabanaFX extends Application {
    
    @Override
    /**
     * Este método es un punto de entrada obligatorio para todas las apps JavaFX. 
     * Aquí es donde se configura la interfaz de usuario inicial.
     * 
     * 1. 'Parent root = FXMLLoader.load(getClass().getResource("PrincipalDocument.fxml"))'
     * carga la interfaz de usuario definida en el archivo FXML 'PrincipalDocument.fxml', 
     * siendo 'Parent' un nodo raíz de la interfaz de usuario.
     * 
     * 2. Se crea una nueva escena ('Scene') con el nodo raíz cargado.
     * 
     * 3. Se establece el título de la ventana, con el método 'setTitle()'.
     * 
     * 4. Se configura la escena en el escenario proporcionado, con el método 'setScene()'.
     * 
     * 5. Se muestra el escenario, lo que hace visible la ventana de la app con la interfaz de usuario
     * cargada, con el método 'show()'.
     */
    public void start(Stage stage) throws Exception {
        
        Parent root = FXMLLoader.load(getClass().getResource("PrincipalDocument.fxml"));
        
        Scene scene = new Scene(root);
        
        stage.setTitle("Salón Habana");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Método principal de la aplicación.
     * 'launch(args)': llama al método 'launch' de la clase 'Application', que eventualmente 
     * lleva a la invocación del método 'start'.
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    } 
}
