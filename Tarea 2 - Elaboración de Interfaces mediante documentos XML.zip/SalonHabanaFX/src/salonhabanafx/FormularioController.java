package salonhabanafx;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.function.UnaryOperator;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Separator;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.control.Tooltip;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Sandra
 */
public class FormularioController implements Initializable {

    @FXML
    private ImageView imagenSalon;

    @FXML
    private Pane panePrincipal, paneOculto;

    @FXML
    private Label labelDatosContacto, labelNombre, labelApellidos, labelTelefono,
            labelAvisoNombre, labelAvisoApellidos, labelAvisoTelefono, labelDatosEvento,
            labelTipoEvento, labelTipoCocina, labelNumPersonas, labelNumJornadas,
            labelHabitacion;

    @FXML
    private Separator separatorOne, separatorTwo, separatorThree, separatorFour;

    @FXML
    private TextField txtNombre, txtApellidos, txtTelefono;

    @FXML
    private Tooltip toolTipNombre, toolTipApellidos, toolTipTelefono, toolTipComboEvento,
            toolTipComboCocina, toolTipNumPersonas, toolTipFecha;

    @FXML
    private ComboBox comboBoxEvento, comboBoxCocina;

    @FXML
    private Spinner<Integer> spinnerNumPersonas, spinnerNumJornadas;

    @FXML
    private DatePicker datePickerFecha;

    @FXML
    private RadioButton radioButtonSi, radioButtonNo;

    @FXML
    private Button buttonFinalizarReserva;

    /**
     * Initializes the controller class.
     * Este método se llama automáticamente al cargar el controlador. Se usa para realizar
     * configuraciones iniciales.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        // Configura TextFields para que acepten solo letras o números.
        configurarTextFieldSoloLetras(txtNombre);
        configurarTextFieldSoloLetras(txtApellidos);
        configurarTextFieldSoloNumeros(txtTelefono);
        // Oculta las etiquetas de aviso.
        labelAvisoNombre.setVisible(false);
        labelAvisoApellidos.setVisible(false);
        labelAvisoTelefono.setVisible(false);
        // Se añaden elementos a los elementos ComboBox.
        comboBoxEvento.getItems().addAll("Banquete", "Jornada", "Congreso");
        comboBoxCocina.getItems().addAll("Buffet", "Carta", "Pedir cita con el chef", "No precisa");
        // Ocultará el panel mientras la opción elegida no sea congreso.
        paneOculto.setVisible(false);

        // Spinner para seleecionar el número de personas. Como mínimo se podrá seleccionar 1 persona y como máximo 500,
        // suponiendo que el salón no tiene capacidad para más. Además el valor inicial se establece en 10, por ejemplo.
        int valorMinimo = 1;
        int valorMaximo = 500;
        int valorInicial = 10;
        SpinnerValueFactory<Integer> valorNumPersonas = new SpinnerValueFactory.IntegerSpinnerValueFactory(valorMinimo, valorMaximo, valorInicial);
        spinnerNumPersonas.setValueFactory(valorNumPersonas);

        // Spinner para seleccionar el número de días que se alquilará el salón si se escoge la opción 'Congreso'.
        // Establezco el mínimo en 1 día y el máximo en 30 (un mes). El valor inicial lo dejo establecido en el mínimo.
        int min = 1;
        int max = 30;
        SpinnerValueFactory<Integer> valorNumJornadas = new SpinnerValueFactory.IntegerSpinnerValueFactory(min, max, min);
        spinnerNumJornadas.setValueFactory(valorNumJornadas);
    }
    
    /**
     * Método que maneja el evento de selección del elemento ComboBoxEvento.
     * Si selecciona 'Congreso', muestra un panel oculto ('paneOculto'), 
     * de lo contrario, lo oculta.
     */
    public void handleComboBoxEvento() {

        if (comboBoxEvento.getValue().equals("Congreso")) {
            paneOculto.setVisible(true);
        } else {
            paneOculto.setVisible(false);
        }
    }
    
    /**
     * Método que gestiona el evento de clic en el botón para finalizar la reserva.
     * 
     * 1. Validaciones: verifica si los 'TextField' nombre, apellidos y teléfono
     * están vacíos y muestra las etiquetas de aviso correspondientes en su caso.
     * Si alguno está vacío, el método retorna y no ejecuta las líneas siguientes.
     * 
     * 2. Cambio de escena: si todos los campos están llenos, carga una nueva escena
     * ('ReservaOKDocument.fxml').
     * @param event
     * @throws IOException 
     */
    public void handleButtonFinalizarReserva(ActionEvent event) throws IOException {

        if (txtNombre.getText().trim().isEmpty()) {
            labelAvisoNombre.setVisible(true);
            labelAvisoApellidos.setVisible(false);
            labelAvisoTelefono.setVisible(false);
            return; // Detiene la ejecución adicional del método
        } else if (txtApellidos.getText().trim().isEmpty()) {
            labelAvisoNombre.setVisible(false);
            labelAvisoApellidos.setVisible(true);
            labelAvisoTelefono.setVisible(false);
            return; // Detiene la ejecución adicional del método
        } else if (txtTelefono.getText().trim().isEmpty()) {
            labelAvisoNombre.setVisible(false);
            labelAvisoApellidos.setVisible(false);
            labelAvisoTelefono.setVisible(true);
            return; // Detiene la ejecución adicional del método
        }

        // Si todos los campos están llenos, procede a cambiar la escena.
        // Este método actúa como el buttonReservar de la clase PrincipalController.java.
        Stage stage = (Stage) buttonFinalizarReserva.getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("ReservaOKDocument.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    /**
     * Método para aceptar que en el 'TextField' solo haya letras.
     * @param textField 
     * 
     * Este método solo podrá utilizarse dentro de esta clase.
     * 
     * 1. Defino un operador unario que trabaja con un objeto "TextFormatter.Change",
     * ya que toma un solo valor y devuelve un valor del mismo tipo.
     * 
     * 2. 'cambio -> {};' es una expresión lambda que define la operación del operador
     * unario. 'Cambio' es una instancia de 'TextFormatter.Change' que representa
     * un cambio que está ocurriendo en el texto 'TextField'.
     * 
     * 3. Obtengo el texto que está siendo insertado o modificado en el 'TextField'.
     * 
     * 4. Compruebo con una expresión regular si el texto contiene solo letras (mayúsculas
     * o minúsculas) y espacios en blanco, ya que serán dos apellidos mínimos. 
     * El asterisco ('*') indica que puede haber 0 o más caracteres,
     * pero todos deben ser letras. Si el texto cumple con la expresión regular, 
     * devuelve el objeto 'cambio', permitiendo que la modificación en el 'Textfield' ocurra.
     * 
     * 5. Si el texto no cumple con la expresión regular, devolverá 'null', lo que impide 
     * que el cambio en el 'TextField' se lleve a cabo.
     * 
     * 6. Por último, se establece el 'TextFormatter' para el 'TextField' proporcionado, 
     * utilizando el 'filtroLetras' definido anteriormente. 'TextFormatter' se utiliza 
     * para modificar y filtrar el texto que ingresa el usuario en el 'TextField'.
     */
    private void configurarTextFieldSoloLetras(TextField textField) {

        UnaryOperator<TextFormatter.Change> filtroLetras = cambio -> {
            String texto = cambio.getText();
            if (texto.matches("[a-zA-Z ]*")) {
                return cambio;
            }
            return null;
        };
        textField.setTextFormatter(new TextFormatter<>(filtroLetras));
    }
    
    /**
     * Método para aceptar que en el 'TextField' solo haya números.
     * @param textField 
     * 
     * Este método solo podrá utilizarse dentro de esta clase y funciona
     * exactamente igual que el anterior.
     */
    private void configurarTextFieldSoloNumeros(TextField textField) {
        UnaryOperator<TextFormatter.Change> filtroNumeros = cambio -> {
            String texto = cambio.getText();
            if (texto.matches("[0-9]*")) {
                return cambio;
            }
            return null;
        };
        textField.setTextFormatter(new TextFormatter<>(filtroNumeros));
    }
}
