package salonhabanafx;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;

/**
 * FXML Controller class
 *
 * @author Sandra
 */
public class ReservaOKController implements Initializable {
    
    @FXML
    private Pane panePrincipal;
    
    @FXML
    private ImageView imageFondo;
    
    @FXML
    private Label labalMensajeOne, labelMensajeDos;
    
    /**
     * Initializes the controller class.
     * Método de inicialización que se ejecuta después de que todos los elementos FXML
     * se hayan cargado completamente.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
