package salonhabanafx;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.stage.Stage;

/**
 *
 * @author Sandra
 * Implementa la interfaz Initializable que realiza acciones de inicialización después de que 
 * sus elementos de interfaz de usuario hayan sido cargados.
 */
public class PrincipalController implements Initializable {
    
    @FXML
    private Button buttonReservar, buttonSalir;

    @FXML
    private MenuBar menuBarra;
    
    @FXML
    private Menu menuArchivo, menuAyuda;
    
    @FXML
    private MenuItem menuItemReservar, menuItemSalir, menuItemSobre;
  
    @Override
    /**
     * Initializes the controller class.
     * Método de inicialización que se ejecuta después de que todos los elementos FXML
     * se hayan cargado completamente.
     */
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }   
    
    /**
     * Método que  maneja clics en el botón de reservar. Carga una nueva escena o vista
     * dependiendo del botón que se presione.
     * @param event
     * @throws IOException 
     * 
     * 1. Se obtiene el escenario actual (ventana en la que se muestra la interfaz).
     * Primero se obtiebe la escena 'Scene', en la que se encuentra el botón 'buttonReservar', 
     * y luego se obtiene la ventana ('window') de esa escena, que se castea a 'Stage'.
     * 
     * 2. Cargar la interfaz de usuario definida en el archivo FXML 'PrincipalDocument.fxml'.
     * 'FXMLLoader.load()' carga el archivo FXML y 'getClass().getResource()' localiza en el mismo
     * paquete o ruta de la clase actual.
     * El resultado se asigna a 'root', que es de tipo 'Parent', la clase base para todos los nodos
     * que tienen hijos en el árbol de la escena.
     * 
     * 3. Esta condición verifica si la fuente del evento ('event.getSource()') es igual al botón ('buttonReservar'),
     * lo que significaría que el botón ha sido presionado.
     * Si es así, vuelve a obtener el escenario ('Stage') actual y se carga una vista diferente, en este caso
     * la del formulario ('FormularioDocument.fxml'), que reemplaza el valor de 'root'.
     * 
     * 4. Por último, se crea una nueva escena ('Scene') utilizando el 'Parent root', que ahora contiene
     * la nueva vista cargada. Esta nueva escena se establece en el 'Stage' actual con 'stage.setScene(scene)'.
     * Finalmente, 'stage.show()' hace que el escenario ('Stage', y por tanto, nueva escena) sea visible.
     */
    public void handleButtonReservar (ActionEvent event) throws IOException{

        Stage stage = (Stage) buttonReservar.getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("PrincipalDocument.fxml"));
        
        if(event.getSource() == buttonReservar){
            stage = (Stage) buttonReservar.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("FormularioDocument.fxml"));
        }

        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    /**
     * Método que cierra la aplicación cuando se presiona el botón salir.
     * @param event 
     * 
     * 1. Platform.extit() - Cierra toda la aplicación.
     * 2. System.exit() - Termina el programa.
     */
    public void handleButtonSalir (ActionEvent event){

        Platform.exit();
        System.exit(0);
    }
    
    /**
     * Método igual a 'handleButtonReservar', pero maneja la acción desde un ítem del menú.
     * @param event
     * @throws IOException 
     */
    public void handleMenuItemReservar(ActionEvent event) throws IOException {
        Stage stage = (Stage) menuItemReservar.getParentPopup().getOwnerWindow();
        Parent root = FXMLLoader.load(getClass().getResource("PrincipalDocument.fxml"));

        if (event.getSource() == menuItemReservar) {
            stage = (Stage) menuItemReservar.getParentPopup().getOwnerWindow();
            root = FXMLLoader.load(getClass().getResource("FormularioDocument.fxml"));
        } 

        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    /**
     * Método que cierra la ventana actual cuando se selecciona la opción salir desde el menú,
     * exactamente igual que 'handleButtonSalir'.
     * @param event 
     */
    public void handleMenuItemSalir(ActionEvent event) {
        Stage stage = (Stage) menuItemSalir.getParentPopup().getOwnerWindow();
        stage.close();
    }
}
